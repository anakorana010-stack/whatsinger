import { createClient } from '@supabase/supabase-js'
export const supabase = createClient(
'https://dofzycogyzhhdousob.supabase.co',
'sb_publishable_Qe0gS8Ws60fdJetE118RBw_0Yffq9sU'
)